const fs = require('fs')
const chalk = require("chalk")


global.botname = "Vanayyis"
global.namaOwner = "ᴋʏʏ ᴅᴇᴠᴇʟᴏᴘᴇʀ"
global.owner = "6283811470532"
global.versi = "1.0"
global.linkWebsite = "https://Vanayyis.com"

// Setting Link //

global.idSaluran = "120363407832038656@newsletter"
global.namasaluran = "ALL TESTI IKYY STORE"
global.idsaluran = "120363407832038656@newsletter"
global.linkGrup = ""
global.linkSaluran = "https://whatsapp.com/channel/0029Vb29Lwc89inkqDLMSH1Y"

// Image //

global.image = {
menu: "https://img1.pixhost.to/images/5264/591713139_fr3hosting.jpg", 
reply: "https://files.catbox.moe/5e73s3.jpg", 
logo: "https://img1.pixhost.to/images/5264/591713139_fr3hosting.jpg", 
dana: "", 
ovo: "", 
gopay: "", 
qris: "https://files.catbox.moe/m38rzg.jpg"
}

global.systemN = "sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ"
global.mess = {
    regis : "*[ sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ ]*\nᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴛᴇʀᴅᴀғᴛᴀʀ sɪʟᴀʜᴋᴀɴ ᴋᴇᴛɪᴋ .ᴅᴀғᴛᴀʀ",
    creator: "*[ sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ ]*\nᴋʜᴜsᴜs ɪᴋʏʏ ɢᴀɴᴛᴇɴɢ",
	owner: "*[ sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ ]*\nʟᴜ ɴɢᴀᴘᴀɪɴ? ᴅᴇᴋ 😹",
	admin: "*[ sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ ]*\nғɪᴛᴜʀ ᴋʜᴜsᴜs ᴀᴅᴍɪɴ",
	botAdmin: "*[ sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ ]*\nʙᴏᴛ ʜᴀʀᴜs ᴀᴅᴍɪɴ",
	group: "*[ sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ ]*\nғɪᴛᴜʀ ɴʏᴀ ᴋʜᴜsᴜs ᴅɪ ɢʀᴏᴜᴘ ʏᴀʜ ᴀɴᴊᴇɴɢ",
	private: "*[ sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ ]*\nғɪᴛᴜʀ ɴʏᴀ ᴋʜᴜsᴜs ᴘʀɪᴠᴀᴛᴇ ʏᴀʜ ᴀɴᴊᴇɴɢ",
    bot : "*[ sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ ]*\nᴏɴʟʏ ʙᴏᴛ ᴜsᴇʀ",
	prem: "*[ sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ ]*\nᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ ᴛᴏʟʟ😹",
	wait: 'ᴡᴀɪᴛɪɴɢ ⏳',
	error: 'ERROR❗',
	done: 'ᴅᴏɴᴇ ✅'
}

// ━━━━ DO NOT CHANGE (しなければならない)
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
